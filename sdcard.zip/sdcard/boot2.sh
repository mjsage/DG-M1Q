#!/bin/sh
#
sh /mnt/disc1/httpd.sh &
