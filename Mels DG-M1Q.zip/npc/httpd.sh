#!/bin/sh

#remount sd card as executable
#mount -t vfat -o rw,exec,umask=000,remount /dev/mmcblk0p1 /mnt/disc1  </dev/null &>/dev/null &
#
echo " remounting SD with exec"
#run httpd server (actually a copy of busybox for arm)
/mnt/disc1/httpd -h /mnt/disc1/npc </dev/null &>/dev/null &
#
#filelist.cgi creates list of files
#find * -exec echo "<a href=\"/{}\">{}</a><br>" \;
#
#
